from flask import Flask,request,render_template
import mysql.connector
import os
import time
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email import encoders
import imghdr


app= Flask(__name__)


mydb = mysql.connector.connect(host="localhost",user="root",password="",database="poultry")
mycursor = mydb.cursor()

def report_send_mail(mailid1,message):
    '''
    This function sends mail
    '''
    #label = "Eye Close"
    #with open(image_path, 'rb') as f:
        #img_data = f.read()
    fromaddr = "pdivyapriya1@gmail.com"
    toaddr = mailid1
    msg = MIMEMultipart()
    msg['From'] = fromaddr
    msg['To'] = toaddr
    msg['Subject'] = "Alert"
    body = message
    msg.attach(MIMEText(body, 'plain'))  # attach plain text
    #image = MIMEImage(img_data, name=os.path.basename(image_path))
    #msg.attach(image) # attach image
    s = smtplib.SMTP('smtp.gmail.com',587)
    s.starttls()
    s.login(fromaddr, "ckzdjdhnolwdgcyt")
    text = msg.as_string()
    s.sendmail(fromaddr, toaddr, text)
    s.quit()

@app.route('/')
@app.route('/login')
def login():
    return render_template('login1.html')

@app.route('/validate',methods=['POST','GET'])
def valid():
    global data1
    if request.method == 'POST':
        data1 = request.form.get('username')
        data2 = request.form.get('password')
        sql = "SELECT * FROM `company` WHERE `name` = %s AND `password` = %s"
        val = (data1, data2)
        mycursor.execute(sql, val)
        account = mycursor.fetchone()

        if data1 == 'admin' and data2 == '1234':
            sql = "SELECT * FROM `detail`"
            mycursor.execute(sql)
            account = mycursor.fetchall()

            return render_template('adminhome.html', data=account)
        elif account:
            sql = "SELECT * FROM `company` WHERE `name` = %s"
            val = (data1,)
            mycursor.execute(sql, val)
            account1 = mycursor.fetchall()


            return render_template('index.html',data=account1)

        else:
            return render_template('login1.html',msg = 'Invalid')

@app.route('/detail',methods=['POST','GET'])
def detail():
    if request.method == 'POST':
        com = request.form.get('r_no')
        branch = request.form.get('n_ame')
        district = request.form.get('p_no')
        print(com)
        print(branch)
        print(district)
        vac = request.form.get('vac')
        num = request.form.get('name')
        age = request.form.get('age')

        his = request.form.get('his')
        feed = request.form.get('feed')
        nutri = request.form.get('nutri')
        prod = request.form.get('prod')
        sale = request.form.get('sale')
        message = request.form.get('message')
        import datetime

        current_datetime = datetime.datetime.now()

        date = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
        sql="INSERT INTO detail (com,batch,num,age,his,feed,nutri,prod,sale,message,date) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        val = (com,vac,num,age,his,feed,nutri,prod,sale,message,date)
        mycursor.execute(sql,val)
        mydb.commit()
        return render_template('success.html')

@app.route('/view',methods=['POST','GET'])
def view():
    if request.method == 'POST':
        com = request.form.get('r_no')
        sql = "SELECT * FROM `company` WHERE `name` = %s"
        val = (com,)
        mycursor.execute(sql,val)
        account = mycursor.fetchall()
        return render_template('message.html',data=account)

@app.route('/mail',methods=['POST','GET'])
def mail():
    if request.method == 'POST':
        com = request.form.get('r_no')
        message = request.form.get('message')
        sql = "SELECT email FROM `company` WHERE `name` = %s"
        val = (com,)
        mycursor.execute(sql, val)
        account = mycursor.fetchall()
        mailid = account[0][0]
        print(mailid)
        report_send_mail(mailid,message)
        return render_template('1.html')


if __name__ == '__main__':
       app.run(debug=True,port= 4000)